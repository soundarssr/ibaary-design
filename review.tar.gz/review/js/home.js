     height=$(window).innerHeight();
     width=$(window).innerWidth();
    alert('load h '+height+' w '+width);

     if (width < 768 && height < 670) {

    $('.page-emerald').removeClass('leftmenu');
      $('#canvas-back').removeClass('show');
      $('#viewport').addClass('portrait');

      $('body').addClass('responsive');
      $('.hide-on-mobile .text').addClass('hide');
     } else{

      $('.landscape').currentTarget.id;
      $('.page-emerald').addClass('leftmenu');
      $('#canvas-back').addClass('show');
        $('#viewport').removeClass('portrait');
        $('body').removeClass('responsive');
        $('.hide-on-mobile .text').removeClass('hide');

         };
